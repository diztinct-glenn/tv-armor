<?php

include_once LAGS_DIR . '/includes/shortcodes/typography-shortcodes.php';

include_once LAGS_DIR . '/includes/shortcodes/video-shortcodes.php';

include_once LAGS_DIR . '/includes/shortcodes/contact-shortcodes.php';

include_once LAGS_DIR . '/includes/shortcodes/column-shortcodes.php';

include_once LAGS_DIR . '/includes/shortcodes/divider-shortcodes.php';

include_once LAGS_DIR . '/includes/shortcodes/box-shortcodes.php';

include_once LAGS_DIR . '/includes/shortcodes/location-shortcodes.php';

include_once LAGS_DIR . '/includes/shortcodes/tabs-shortcodes.php';

include_once LAGS_DIR . '/includes/shortcodes/posts-shortcodes.php';

include_once LAGS_DIR . '/includes/shortcodes/button-shortcodes.php';

include_once LAGS_DIR . '/includes/shortcodes/social-shortcodes.php';

include_once LAGS_DIR . '/includes/shortcodes/team-shortcodes.php';

include_once LAGS_DIR . '/includes/shortcodes/testimonials-shortcodes.php';

include_once LAGS_DIR . '/includes/shortcodes/pricing-shortcodes.php';

include_once LAGS_DIR . '/includes/shortcodes/protected-content-shortcodes.php';

include_once LAGS_DIR . '/includes/shortcodes/slider-shortcodes.php';

include_once LAGS_DIR . '/includes/shortcodes/miscellaneous-shortcodes.php';